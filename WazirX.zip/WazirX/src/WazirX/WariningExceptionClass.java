package WazirX;

public class WariningExceptionClass extends Exception {
	
	private static final long serialVersionUID = 1L;
	String warning;
	WariningExceptionClass(String warning){
	this.warning=warning;
	}
	public String getwarning() {
		return warning;
	}
	
}
