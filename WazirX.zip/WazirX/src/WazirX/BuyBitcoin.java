package WazirX;

public class BuyBitcoin {
	private String name;
	private int quantity;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getquantity() {
		return quantity;
	}
	public void setquantity(int quantity) throws WariningExceptionClass {
		if (quantity<=2)
			this.quantity = quantity;
		else
			throw new WariningExceptionClass("BuyingMoreThanTwoBitcoinYouNeedToFileTax");
	}
	
	public String toString() {
				return "congrats " +name + " you have purchased " +  quantity + " bitcoins  " ;			
				}
	
	public BuyBitcoin(String name, int quantity) throws WariningExceptionClass {
		super();
		setName(name);
		setquantity(quantity) ;
		
	}
}
