package WazirX;
 import java.util.Scanner;
public class WazirX {
	static {
		System.out.println("Welcome to WazirX");
	}
	public static void main(String[] args) {
		Scanner inp=new Scanner(System.in);
		System.out.println("Please Enter Your Name");
		String name=inp.next();
		System.out.println("Please Enter Bitcoin Quantity");
		int quantity=inp.nextInt();
		
		try {
			BuyBitcoin buyBitcoin=new BuyBitcoin(name,quantity);
			System.out.println(buyBitcoin);
		}
		catch (WariningExceptionClass e) {
			 System.err.println(name+" "+e.warning);
			 System.out.println("Please ReEnter Quantity If You Agree  ");			 
		}		
		int tax=inp.nextInt();
		if (tax==quantity)			
			System.out.println("congrats "+name+" "+" you have purchased "+quantity +" bitcoins");
		else
			System.err.println("Try again!!");
		}			
}
